//コンソール出力
console.log("Hello World")